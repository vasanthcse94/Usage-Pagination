const {app, BrowserWindow} = require('electron')
/* const {Tray, Menu} = require('electron')
const notifier = require('node-notifier') */
const url = require('url') 
const path = require('path')  

let win  

function createWindow() { 
	win = new BrowserWindow({width: 600, height: 700, resizable:false})
	// win.setMenu(null)
	win.once('ready-to-show', () => {
		win.show()
	})
	win.loadURL(url.format ({ 
		pathname: path.join(__dirname, '/src/forms/index.html'), 
		protocol: 'file:', 
		slashes: true 
	}))	

	/* let trayIcon = new Tray(path.join(__dirname, '/src/img/t-mobile.png'))

	const trayMenuTemplate = [
		{
		   label: 'T-Mobile DB',
		   enabled: false
		},
		{
		   label: 'Help',
		   click: function () {
			notifier.notify ({
			   title: 'My awesome title',
			   message: 'Hello from electron, Mr. User!',
			   icon: path.join(__dirname, '/src/img/t-mobile.png'),
			   wait: true

			}, function (err, response) {
			   // Response is response from notification
			});

			notifier.on('click', function (notifierObject, options) {
			   console.log("You clicked on the notification")
			});

			notifier.on('timeout', function (notifierObject, options) {
			   console.log("Notification timed out!")
			});
		   }
		}
	]
	let trayMenu = Menu.buildFromTemplate(trayMenuTemplate)
	trayIcon.setContextMenu(trayMenu) */
}  

app.on('ready', createWindow)