/**
* usageCustomPagination.js
* jQuery Custom Pagination Plugin.
*/

(function($){
	
	var methods = {
		init: function(options) {
			var o = $.extend({				
				currentPage: 0,
				prevText: '&lt;',
				nextText: '&gt;',
				ellipseText: '&hellip;',
				listStyleClass: '',
				labelMap: [],
				moreRowsIndicator: false,
				onPageClick: function(pageNumber, event) {
					console.log(pageNumber);
				},
				onInit: function() {
					console.log("Plugin Initiated");
				}
			}, options || {});

			var self = this;
			
			if (o.currentPage)
				o.currentPage = o.currentPage - 1;

			this.each(function() {
				self.addClass('usage-pagination').data('pagination', o);
				methods._draw.call(self);
			});
			o.onInit();
			
			return this;
		},
		
		destroy: function(){
			this.empty();
			return this;
		},
		
		_draw: function() {
			var	self=this, o = this.data('pagination'), i, tagName;
			
			methods.destroy.call(this);
			
			tagName = (typeof this.prop === 'function') ? this.prop('tagName') : this.attr('tagName');
			console.log(this.prop('tagName'))
			var panel = tagName === 'UL' ? this : $('<ul' + (o.listStyleClass ? ' class="' + o.listStyleClass + '"' : '') + '></ul>').appendTo(this);
			
			if(o.moreRowsIndicator || 0 != o.currentPage) {
				// Generate Prev link
				if (o.prevText) {
					methods._appendItem.call(this, o.currentPage - 1, {text: o.prevText, classes: 'prev'});
				}			
				
				// Generate Page Number			
				(o.currentPage > 1) && panel.append('<li><span class="l-ellipse">' + o.ellipseText + '</span></li>');
				(o.currentPage > 0) && methods._appendItem.call(this, o.currentPage - 1);						
				methods._appendItem.call(this, o.currentPage);
				if (o.moreRowsIndicator) {
					methods._appendItem.call(this, o.currentPage + 1);
					panel.append('<li><span class="r-ellipse">' + o.ellipseText + '</span></li>');
				}			

				// Generate Next link (unless option is set for at front)
				if (o.nextText) {
					methods._appendItem.call(this, o.currentPage + 1, {text: o.nextText, classes: 'next'});
				}
			}
			
			panel.find('.l-ellipse').click(function(event) {
				o.currentPage = 0;
				methods._draw.call(self);
				return o.onPageClick(1, event);				
			});
		},
				
		_appendItem: function(pageIndex, opts) {
			var self = this, options, $link, 
				o = self.data('pagination'), 
				$linkWrapper = $('<li></li>');
				
			pageIndex = pageIndex < 0 ? 0 : pageIndex;//(pageIndex < o.pages ? pageIndex : o.pages - 1);

			options = {
				text: pageIndex + 1,
				classes: ''
			};

			if (o.labelMap.length && o.labelMap[pageIndex]) {
				options.text = o.labelMap[pageIndex];
			}

			options = $.extend(options, opts || {});
			
			if (pageIndex == o.currentPage || o.disabled) {
				console.log(o.disabled)
				if (o.disabled || options.classes === 'prev' || options.classes === 'next') {
					$linkWrapper.addClass('disabled');
				} else {
					$linkWrapper.addClass('active');
				}
				$link = $('<span class="current">' + options.text + '</span>');
			} else {
				$link = $('<span>' + options.text + '</span>');				
				$link.click(function(event){
					if(!o.moreRowsIndicator && options.classes === 'next') {
						return false;
					}
					return methods._selectPage.call(self, pageIndex, event);
				});
			}
			if (options.classes) {
				$link.addClass(options.classes);
			}
			$linkWrapper.append($link);
			
			$ul = self.find('ul');
			($ul.length) ? $ul.append($linkWrapper) : self.append($linkWrapper);		
		},
		
		_selectPage: function(pageIndex, event) {
			var o = this.data('pagination');
			o.currentPage = pageIndex;
			methods._draw.call(this);
			return o.onPageClick(pageIndex + 1, event);
		}
	};
	
	
	$.fn.usagePagination = function(method) {
		if (typeof method === 'object' || !method) {
			return methods.init.apply(this, arguments);
		} else {
			$.error('Method : ' +  method + ' does not exist on jQuery.pagination');
		}
	};
})(jQuery);